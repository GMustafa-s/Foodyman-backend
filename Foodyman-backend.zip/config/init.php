<?php
 return [
                        
'name' => 'Foodyman.pk',
                        
'favicon' => 'https://example/storage/images/shops/0001-1741331804.webp',
                        
'logo' => 'https://example/storage/images/shops/0001-1741331798.webp',
                        
'delivery' => '1',
                        
'shop_type' => '1',
                        
];